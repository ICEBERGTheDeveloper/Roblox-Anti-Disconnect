## Installation
* First, you need to download AutoHotKey v1.1 (Not 2.0!), and run the installer
* Once complete, download the most recent version of the Anti-Disconnect through the most recent GitHub Release(Download source code ZIP)
* After downloading, extract the ZIP file to your desired directory
## Before starting the macro:
* ensure you extracted the macro file
* don't go full screen, be in windowed fullscreen
* make sure you have selected at least one action
## Features
Anti-Disconnect has lots of features to keep you in game while you go afk, these are the following:

* Resets your character
* Moves your character forward and then backward again
* Moves your camera left and right
* says custom messages in the chat! you can select one of the above actions, and also change how often it does that action right in the Anti-Disconnect Menu!
Our Discord: discord.gg/5Y5QQXrcGp